"""IMPORT DATASET"""
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split

import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv("data.csv")

#print(df)

#print(df.info())

df.drop(df.columns[0],axis=1,inplace=True)

#print(df['diagnosis'].value_counts())


"""FEATURE SELECTION"""

diag_map = {'M' : 1 ,'B' : 0}

df['diagnosis']  = df['diagnosis'].map(diag_map)

print(df.columns)

X = df.drop(columns=['diagnosis','Unnamed: 32'])
print(X)

Y = df[['diagnosis']]

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.25,random_state=42)
from sklearn.metrics import accuracy_score



from sklearn.neighbors import KNeighborsClassifier

knn =KNeighborsClassifier()

knn.fit(X_train,Y_train)

kn_y_pred = knn.predict(X_test)


acc = accuracy_score(kn_y_pred,Y_test)
print(acc)


from sklearn.linear_model import LogisticRegression

l_r = LogisticRegression()

l_r.fit(X_train,Y_train)

l_r_pred = l_r.predict(X_test)

acc_lr = accuracy_score(l_r_pred,Y_test)
print(acc_lr)



from sklearn.naive_bayes import GaussianNB

gb = GaussianNB()

gb.fit(X_train,Y_train)

gb_pred =gb.predict(X_test)

acc_gb = accuracy_score(gb_pred,Y_test)
print(acc_gb)


from sklearn.model_selection import cross_val_score

acc_all =[]

cvs_all =[]

scr = cross_val_score(knn,X,Y,cv=10)

acc_all.append(accuracy_score(kn_y_pred,Y_test))
cvs_all.append(np.mean((scr)))

print("ACC_SCORE :{0:.2%}".format(accuracy_score(kn_y_pred,Y_test)))

print("CROSS_VAL {0:.2%} (+/-   {1:.2%})".format(np.mean(scr),np.std(scr)*2))



acc_all_lr =[]

cvs_all_lr =[]

scr_lr = cross_val_score(l_r,X,Y,cv=10)

acc_all_lr.append(accuracy_score(l_r_pred,Y_test))
cvs_all_lr.append(np.mean((scr_lr)))

print("ACC_SCORE :{0:.2%}".format(accuracy_score(l_r_pred,Y_test)))

print("CROSS_VAL {0:.2%} (+/-   {1:.2%})".format(np.mean(scr),np.std(scr)*2))




acc_all_gb =[]

cvs_all_gb =[]

scr_gb = cross_val_score(gb,X,Y,cv=10)

acc_all.append(accuracy_score(gb_pred,Y_test))
cvs_all.append(np.mean((scr_gb)))

print("ACC_SCORE :{0:.2%}".format(accuracy_score(gb_pred,Y_test)))

print("CROSS_VAL {0:.2%} (+/-   {1:.2%})".format(np.mean(scr),np.std(scr)*2))